export class Produto {
    constructor(

        public id: string = "",
        public titulo: string = "",
        public preco: number = 0,
        public descricao: number = 0,
        public qtde: number = 0,
        public categoria: number = 0,
    ) {

    }
}