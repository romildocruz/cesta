import { Component, OnInit } from '@angular/core';
import { Produto } from 'src/app/models/produto.model';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-produto-list',
  templateUrl: './produto-list.component.html',
  styleUrls: ['./produto-list.component.css']
})
export class ProdutoListComponent implements OnInit {
  public produtos: Produto[];
  public Categorias: any[] = []

  constructor(
    private service: DataService
  ) { }

  ngOnInit() {
    this.service
      .get()
      .subscribe(
        (res: any) => {
          this.produtos = res;
        }
      )
  }

  loadCategorias() {
    this.Categorias = [];
    this.Categorias.push({ id: 'BRA', descricao: 'Brasil' });
    this.Categorias.push({ id: 'EUA', descricao: 'Estados Unidos' });
    this.Categorias.push({ id: 'ITA', descricao: 'Itália' });
  }

}
